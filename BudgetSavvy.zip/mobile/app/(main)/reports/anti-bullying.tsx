import AntiBullyingReportScreen from '@/screens/reports/AntiBullyingReportScreen';

export default AntiBullyingReportScreen;