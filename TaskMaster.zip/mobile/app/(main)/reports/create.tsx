import CreateReportScreen from '@/screens/reports/CreateReportScreen';

export default CreateReportScreen;