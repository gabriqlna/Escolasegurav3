package com.escolaseguranca.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
