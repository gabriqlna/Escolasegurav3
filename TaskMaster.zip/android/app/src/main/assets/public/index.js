// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
import { randomUUID } from "crypto";
var MemStorage = class {
  users;
  reports;
  notices;
  visitors;
  occurrences;
  checklistItems;
  drills;
  campaigns;
  emergencyAlerts;
  constructor() {
    this.users = /* @__PURE__ */ new Map();
    this.reports = /* @__PURE__ */ new Map();
    this.notices = /* @__PURE__ */ new Map();
    this.visitors = /* @__PURE__ */ new Map();
    this.occurrences = /* @__PURE__ */ new Map();
    this.checklistItems = /* @__PURE__ */ new Map();
    this.drills = /* @__PURE__ */ new Map();
    this.campaigns = /* @__PURE__ */ new Map();
    this.emergencyAlerts = /* @__PURE__ */ new Map();
  }
  // Users
  async getUser(id) {
    return this.users.get(id);
  }
  async getUserByEmail(email) {
    return Array.from(this.users.values()).find((user) => user.email === email);
  }
  async getUserByFirebaseUid(firebaseUid) {
    return Array.from(this.users.values()).find((user) => user.firebaseUid === firebaseUid);
  }
  async createUser(insertUser) {
    const id = randomUUID();
    const user = {
      ...insertUser,
      role: insertUser.role ?? "aluno",
      id,
      isActive: true,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.users.set(id, user);
    return user;
  }
  async updateUser(id, updates) {
    const user = this.users.get(id);
    if (!user) return void 0;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  async getAllUsers() {
    return Array.from(this.users.values());
  }
  // Reports
  async createReport(reportData) {
    const id = randomUUID();
    const report = {
      ...reportData,
      title: reportData.type,
      // Use type as title for now
      location: null,
      description: reportData.description,
      priority: "medium",
      updatedAt: null,
      resolvedAt: null,
      resolvedBy: null,
      resolution: null,
      isAnonymous: reportData.isAnonymous ?? false,
      id,
      reporterId: reportData.reporterId || null,
      status: "pending",
      createdAt: /* @__PURE__ */ new Date()
    };
    this.reports.set(id, report);
    return report;
  }
  async getReports() {
    return Array.from(this.reports.values());
  }
  async getReport(id) {
    return this.reports.get(id);
  }
  async updateReportStatus(id, status) {
    const report = this.reports.get(id);
    if (!report) return void 0;
    const updatedReport = { ...report, status };
    this.reports.set(id, updatedReport);
    return updatedReport;
  }
  // Notices
  async createNotice(noticeData) {
    const id = randomUUID();
    const notice = {
      ...noticeData,
      id,
      priority: "medium",
      targetAudience: ["aluno", "funcionario", "direcao"],
      updatedAt: null,
      expiresAt: null,
      isActive: true,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.notices.set(id, notice);
    return notice;
  }
  async getActiveNotices() {
    return Array.from(this.notices.values()).filter((notice) => notice.isActive);
  }
  async updateNotice(id, updates) {
    const notice = this.notices.get(id);
    if (!notice) return void 0;
    const updatedNotice = { ...notice, ...updates };
    this.notices.set(id, updatedNotice);
    return updatedNotice;
  }
  // Visitors
  async createVisitor(visitorData) {
    const id = randomUUID();
    const visitor = {
      ...visitorData,
      id,
      phone: null,
      hostName: visitorData.hostName,
      hostId: null,
      checkInTime: /* @__PURE__ */ new Date(),
      checkOutTime: null,
      status: "checked_in",
      badgeNumber: null,
      checkOutNote: null,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: null
    };
    this.visitors.set(id, visitor);
    return visitor;
  }
  async getActiveVisitors() {
    return Array.from(this.visitors.values()).filter((visitor) => !visitor.checkOutTime);
  }
  async getVisitors() {
    return Array.from(this.visitors.values());
  }
  async checkOutVisitor(id) {
    const visitor = this.visitors.get(id);
    if (!visitor) return void 0;
    const updatedVisitor = { ...visitor, exitTime: /* @__PURE__ */ new Date() };
    this.visitors.set(id, updatedVisitor);
    return updatedVisitor;
  }
  // Occurrences
  async createOccurrence(occurrenceData) {
    const id = randomUUID();
    const occurrence = {
      ...occurrenceData,
      severity: occurrenceData.severity ?? "medium",
      id,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.occurrences.set(id, occurrence);
    return occurrence;
  }
  async getOccurrences() {
    return Array.from(this.occurrences.values());
  }
  // Checklist Items
  async createChecklistItem(itemData) {
    const id = randomUUID();
    const item = {
      ...itemData,
      description: itemData.description ?? null,
      id,
      isCompleted: false,
      completedBy: null,
      completedAt: null,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.checklistItems.set(id, item);
    return item;
  }
  async getChecklistItems() {
    return Array.from(this.checklistItems.values());
  }
  async updateChecklistItem(id, updates) {
    const item = this.checklistItems.get(id);
    if (!item) return void 0;
    const updatedItem = { ...item, ...updates };
    this.checklistItems.set(id, updatedItem);
    return updatedItem;
  }
  // Drills
  async createDrill(drillData) {
    const id = randomUUID();
    const drill = {
      ...drillData,
      type: drillData.type ?? "evacuation",
      description: drillData.description ?? null,
      id,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.drills.set(id, drill);
    return drill;
  }
  async getDrills() {
    return Array.from(this.drills.values());
  }
  async getUpcomingDrills() {
    const now = /* @__PURE__ */ new Date();
    return Array.from(this.drills.values()).filter((drill) => drill.scheduledDate > now);
  }
  // Campaigns
  async createCampaign(campaignData) {
    const id = randomUUID();
    const campaign = {
      ...campaignData,
      id,
      isActive: true,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }
  async getActiveCampaigns() {
    return Array.from(this.campaigns.values()).filter((campaign) => campaign.isActive);
  }
  async updateCampaign(id, updates) {
    const campaign = this.campaigns.get(id);
    if (!campaign) return void 0;
    const updatedCampaign = { ...campaign, ...updates };
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }
  // Emergency Alerts
  async createEmergencyAlert(alertData) {
    const id = randomUUID();
    const alert = {
      ...alertData,
      location: alertData.location ?? null,
      id,
      isResolved: false,
      resolvedBy: null,
      resolvedAt: null,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.emergencyAlerts.set(id, alert);
    return alert;
  }
  async getActiveEmergencyAlerts() {
    return Array.from(this.emergencyAlerts.values()).filter((alert) => !alert.isResolved);
  }
  async resolveEmergencyAlert(id, resolvedBy) {
    const alert = this.emergencyAlerts.get(id);
    if (!alert) return void 0;
    const updatedAlert = {
      ...alert,
      isResolved: true,
      resolvedBy,
      resolvedAt: /* @__PURE__ */ new Date()
    };
    this.emergencyAlerts.set(id, updatedAlert);
    return updatedAlert;
  }
};
var storage = new MemStorage();

// shared/schema.ts
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  firebaseUid: text("firebase_uid").notNull().unique(),
  role: text("role").$type().notNull().default("aluno"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  // 'Bullying', 'Drogas', 'Vandalismo', 'Ameaça', 'Outro'
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location"),
  isAnonymous: boolean("is_anonymous").notNull().default(false),
  reporterId: varchar("reporter_id").references(() => users.id),
  status: text("status").notNull().default("pending"),
  // pending, in_progress, resolved, rejected
  priority: text("priority").notNull().default("medium"),
  // low, medium, high, urgent
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at"),
  resolvedAt: timestamp("resolved_at"),
  resolvedBy: varchar("resolved_by").references(() => users.id),
  resolution: text("resolution")
});
var notices = pgTable("notices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  priority: text("priority").notNull().default("medium"),
  // low, medium, high, urgent
  targetAudience: text("target_audience").array().notNull(),
  // ['aluno', 'funcionario', 'direcao']
  isActive: boolean("is_active").notNull().default(true),
  expiresAt: timestamp("expires_at"),
  createdBy: varchar("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
});
var visitors = pgTable("visitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  document: text("document").notNull(),
  phone: text("phone"),
  purpose: text("purpose").notNull(),
  hostName: text("host_name").notNull(),
  hostId: varchar("host_id").references(() => users.id),
  checkInTime: timestamp("check_in_time").defaultNow().notNull(),
  checkOutTime: timestamp("check_out_time"),
  status: text("status").notNull().default("checked_in"),
  // checked_in, checked_out
  badgeNumber: text("badge_number"),
  checkOutNote: text("check_out_note"),
  registeredBy: varchar("registered_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
});
var occurrences = pgTable("occurrences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull().default("medium"),
  // low, medium, high
  createdBy: varchar("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var checklistItems = pgTable("checklist_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedBy: varchar("completed_by").references(() => users.id),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var drills = pgTable("drills", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  scheduledDate: timestamp("scheduled_date").notNull(),
  type: text("type").notNull().default("evacuation"),
  // evacuation, fire, earthquake, etc
  createdBy: varchar("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  // digital_safety, traffic_education, general
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var emergencyAlerts = pgTable("emergency_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  message: text("message").notNull(),
  location: text("location"),
  triggeredBy: varchar("triggered_by").references(() => users.id).notNull(),
  isResolved: boolean("is_resolved").notNull().default(false),
  resolvedBy: varchar("resolved_by").references(() => users.id),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var insertUserSchema = createInsertSchema(users).pick({
  name: true,
  email: true,
  firebaseUid: true,
  role: true
});
var insertReportSchema = createInsertSchema(reports).pick({
  type: true,
  description: true,
  isAnonymous: true
});
var insertNoticeSchema = createInsertSchema(notices).pick({
  title: true,
  content: true
});
var insertVisitorSchema = createInsertSchema(visitors).pick({
  name: true,
  document: true,
  purpose: true,
  hostName: true
});
var insertOccurrenceSchema = createInsertSchema(occurrences).pick({
  title: true,
  description: true,
  severity: true
});
var insertChecklistItemSchema = createInsertSchema(checklistItems).pick({
  title: true,
  description: true
});
var insertDrillSchema = createInsertSchema(drills).pick({
  title: true,
  description: true,
  scheduledDate: true,
  type: true
}).extend({
  scheduledDate: z.coerce.date()
});
var insertCampaignSchema = createInsertSchema(campaigns).pick({
  title: true,
  content: true,
  category: true
});
var insertEmergencyAlertSchema = createInsertSchema(emergencyAlerts).pick({
  message: true,
  location: true
});
var updateUserSchema = insertUserSchema.partial();
var updateNoticeSchema = insertNoticeSchema.partial();
var updateCampaignSchema = insertCampaignSchema.partial();
var updateChecklistItemSchema = insertChecklistItemSchema.partial().extend({
  isCompleted: z.boolean().optional()
});
var reportStatusSchema = z.object({
  status: z.enum(["pending", "reviewed", "resolved"])
});

// server/routes.ts
async function registerRoutes(app2) {
  const handleAsync = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
  const validateBody = (schema) => (req, res, next) => {
    try {
      req.validatedBody = schema.parse(req.body);
      next();
    } catch (error) {
      res.status(400).json({ error: "Validation failed", details: error.errors });
    }
  };
  const requireAuth = () => (req, res, next) => {
    const userId = req.headers["x-user-id"];
    if (!userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    req.userId = userId;
    next();
  };
  const verifyUser = async (userId) => {
    const user = await storage.getUser(userId);
    if (!user || !user.isActive) {
      return null;
    }
    return user;
  };
  const requireRole = (allowedRoles) => (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: "Forbidden: insufficient permissions" });
    }
    next();
  };
  app2.get("/api/users", handleAsync(async (req, res) => {
    const users2 = await storage.getAllUsers();
    res.json(users2);
  }));
  app2.get("/api/users/:id", handleAsync(async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  }));
  app2.post("/api/users", validateBody(insertUserSchema), handleAsync(async (req, res) => {
    const user = await storage.createUser(req.validatedBody);
    res.status(201).json(user);
  }));
  app2.patch("/api/users/:id", requireAuth(), validateBody(updateUserSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    if (req.params.id !== req.userId && user.role !== "direcao") {
      return res.status(403).json({ error: "Forbidden: can only update own profile" });
    }
    if (req.validatedBody.role && user.role !== "direcao") {
      return res.status(403).json({ error: "Forbidden: cannot change role" });
    }
    const updatedUser = await storage.updateUser(req.params.id, req.validatedBody);
    if (!updatedUser) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(updatedUser);
  }));
  app2.get("/api/reports", handleAsync(async (req, res) => {
    const reports2 = await storage.getReports();
    res.json(reports2);
  }));
  app2.post("/api/reports", validateBody(insertReportSchema), handleAsync(async (req, res) => {
    const reporterId = req.headers["x-user-id"] || void 0;
    const report = await storage.createReport({
      ...req.validatedBody,
      reporterId: req.validatedBody.isAnonymous ? void 0 : reporterId
    });
    res.status(201).json(report);
  }));
  app2.patch("/api/reports/:id/status", requireAuth(), validateBody(reportStatusSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    if (user.role === "aluno") {
      return res.status(403).json({ error: "Forbidden: insufficient permissions" });
    }
    const report = await storage.updateReportStatus(req.params.id, req.validatedBody.status);
    if (!report) {
      return res.status(404).json({ error: "Report not found" });
    }
    res.json(report);
  }));
  app2.get("/api/notices", handleAsync(async (req, res) => {
    const notices2 = await storage.getActiveNotices();
    res.json(notices2);
  }));
  app2.post("/api/notices", requireAuth(), validateBody(insertNoticeSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const notice = await storage.createNotice({
      ...req.validatedBody,
      createdBy: req.userId
    });
    res.status(201).json(notice);
  }));
  app2.patch("/api/notices/:id", requireAuth(), validateBody(updateNoticeSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    if (user.role === "aluno") {
      return res.status(403).json({ error: "Forbidden: insufficient permissions" });
    }
    const notice = await storage.updateNotice(req.params.id, req.validatedBody);
    if (!notice) {
      return res.status(404).json({ error: "Notice not found" });
    }
    res.json(notice);
  }));
  app2.get("/api/visitors", handleAsync(async (req, res) => {
    const visitors2 = await storage.getVisitors();
    res.json(visitors2);
  }));
  app2.get("/api/visitors/active", handleAsync(async (req, res) => {
    const visitors2 = await storage.getActiveVisitors();
    res.json(visitors2);
  }));
  app2.post("/api/visitors", requireAuth(), validateBody(insertVisitorSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const visitor = await storage.createVisitor({
      ...req.validatedBody,
      registeredBy: req.userId
    });
    res.status(201).json(visitor);
  }));
  app2.patch("/api/visitors/:id/checkout", requireAuth(), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const visitor = await storage.checkOutVisitor(req.params.id);
    if (!visitor) {
      return res.status(404).json({ error: "Visitor not found" });
    }
    res.json(visitor);
  }));
  app2.get("/api/occurrences", handleAsync(async (req, res) => {
    const occurrences2 = await storage.getOccurrences();
    res.json(occurrences2);
  }));
  app2.post("/api/occurrences", requireAuth(), validateBody(insertOccurrenceSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const occurrence = await storage.createOccurrence({
      ...req.validatedBody,
      createdBy: req.userId
    });
    res.status(201).json(occurrence);
  }));
  app2.get("/api/checklist", handleAsync(async (req, res) => {
    const items = await storage.getChecklistItems();
    res.json(items);
  }));
  app2.post("/api/checklist", requireAuth(), validateBody(insertChecklistItemSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    if (user.role === "aluno") {
      return res.status(403).json({ error: "Forbidden: insufficient permissions" });
    }
    const item = await storage.createChecklistItem(req.validatedBody);
    res.status(201).json(item);
  }));
  app2.patch("/api/checklist/:id", validateBody(updateChecklistItemSchema), handleAsync(async (req, res) => {
    let updates = { ...req.validatedBody };
    if (req.validatedBody.isCompleted !== void 0) {
      const userId = req.headers["x-user-id"];
      if (!userId) {
        return res.status(401).json({ error: "Authentication required to complete items" });
      }
      const user = await verifyUser(userId);
      if (!user) {
        return res.status(401).json({ error: "Invalid user" });
      }
      if (req.validatedBody.isCompleted) {
        updates = {
          ...updates,
          completedBy: userId,
          completedAt: /* @__PURE__ */ new Date()
        };
      } else {
        updates = {
          ...updates,
          completedBy: null,
          completedAt: null
        };
      }
    }
    const item = await storage.updateChecklistItem(req.params.id, updates);
    if (!item) {
      return res.status(404).json({ error: "Checklist item not found" });
    }
    res.json(item);
  }));
  app2.get("/api/drills", handleAsync(async (req, res) => {
    const drills2 = await storage.getDrills();
    res.json(drills2);
  }));
  app2.get("/api/drills/upcoming", handleAsync(async (req, res) => {
    const drills2 = await storage.getUpcomingDrills();
    res.json(drills2);
  }));
  app2.post("/api/drills", requireAuth(), validateBody(insertDrillSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const drill = await storage.createDrill({
      ...req.validatedBody,
      createdBy: req.userId
    });
    res.status(201).json(drill);
  }));
  app2.get("/api/campaigns", handleAsync(async (req, res) => {
    const campaigns2 = await storage.getActiveCampaigns();
    res.json(campaigns2);
  }));
  app2.post("/api/campaigns", requireAuth(), validateBody(insertCampaignSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const campaign = await storage.createCampaign({
      ...req.validatedBody,
      createdBy: req.userId
    });
    res.status(201).json(campaign);
  }));
  app2.patch("/api/campaigns/:id", requireAuth(), validateBody(updateCampaignSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    if (user.role === "aluno") {
      return res.status(403).json({ error: "Forbidden: insufficient permissions" });
    }
    const campaign = await storage.updateCampaign(req.params.id, req.validatedBody);
    if (!campaign) {
      return res.status(404).json({ error: "Campaign not found" });
    }
    res.json(campaign);
  }));
  app2.get("/api/emergency-alerts", handleAsync(async (req, res) => {
    const alerts = await storage.getActiveEmergencyAlerts();
    res.json(alerts);
  }));
  app2.post("/api/emergency-alerts", requireAuth(), validateBody(insertEmergencyAlertSchema), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const alert = await storage.createEmergencyAlert({
      ...req.validatedBody,
      triggeredBy: req.userId
    });
    res.status(201).json(alert);
  }));
  app2.patch("/api/emergency-alerts/:id/resolve", requireAuth(), handleAsync(async (req, res) => {
    const user = await verifyUser(req.userId);
    if (!user) {
      return res.status(401).json({ error: "Invalid user" });
    }
    const alert = await storage.resolveEmergencyAlert(req.params.id, req.userId);
    if (!alert) {
      return res.status(404).json({ error: "Emergency alert not found" });
    }
    res.json(alert);
  }));
  app2.get("/api/dashboard/stats", handleAsync(async (req, res) => {
    const [users2, reports2, activeVisitors, activeAlerts, upcomingDrills] = await Promise.all([
      storage.getAllUsers(),
      storage.getReports(),
      storage.getActiveVisitors(),
      storage.getActiveEmergencyAlerts(),
      storage.getUpcomingDrills()
    ]);
    const stats = {
      totalUsers: users2.length,
      pendingReports: reports2.filter((r) => r.status === "pending").length,
      activeVisitors: activeVisitors.length,
      activeAlerts: activeAlerts.length,
      upcomingDrills: upcomingDrills.length,
      recentReports: reports2.slice(-5).reverse()
    };
    res.json(stats);
  }));
  app2.use((error, req, res, next) => {
    console.error("API Error:", error);
    res.status(500).json({
      error: "Internal server error",
      message: error.message
    });
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { fileURLToPath } from "url";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var __dirname = path.dirname(fileURLToPath(import.meta.url));
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "client", "src"),
      "@shared": path.resolve(__dirname, "shared"),
      "@assets": path.resolve(__dirname, "attached_assets")
    }
  },
  root: path.resolve(__dirname, "client"),
  build: {
    outDir: path.resolve(__dirname, "dist"),
    emptyOutDir: true
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    hmr: {
      // Better WebSocket handling for Replit environment
      clientPort: 443,
      protocol: "wss"
    },
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
