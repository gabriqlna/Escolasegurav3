import EmergencyScreen from '@/screens/emergency/EmergencyScreen';

export default EmergencyScreen;