import ReportsListScreen from '@/screens/reports/ReportsListScreen';

export default ReportsListScreen;